import logo from './logo.svg';
import './App.css';
import './css/style.css'
import Home from './components/Home'
import GlobalState from './components/GlobalState';
import SignUp from './components/SignUp'
import { useState } from 'react';
import { BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import SignIn from './components/SignIn';
import {toast} from 'react-toastify'; 
import 'react-toastify/dist/ReactToastify.css'; 
import ProductList from './components/ProductList';
import ProductDetails from './components/ProductDetails'
toast.configure()

function App() {
  const [globalState, updateGlobalState]=useState({"users":[]});
  if(globalState.users.length != 0){
    localStorage.setItem('globalState',JSON.stringify(globalState));
  }
  return (
    <GlobalState.Provider value={[globalState, updateGlobalState]}>
       <Router>
         <Switch>
            <Route path='/' exact component={Home}>
              <Home></Home>
            </Route>
            <Route path='/SignIn' component={SignIn}>
              <SignIn></SignIn>
            </Route>
            <Route path='/productList' exact component={ProductList}></Route>
            <Route path='/productList/:productId' component={ProductDetails}></Route>
         </Switch>
       </Router>
    </GlobalState.Provider>
  );
}

export default App;
