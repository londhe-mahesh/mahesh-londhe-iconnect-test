import React, {useState} from 'react'
import { Link } from 'react-router-dom'
import {BiRupee} from 'react-icons/bi'

function Product(props){
    const {id, title, image, quantity, price, description}=props.product;
    return(
        <Link to={
            {
                pathname: `/productList/${id}`,
                state: {
                    product: props.product
                }
            }
        } className='product card' key={id}>
            <div className='product-image'>
                 <img src={image}/>
            </div>
           <div className='title'>
                <p>{title}</p>
           </div>
           <div className='description'>
                 <p>{description}</p>
           </div>
           <div className='quantity'>
                 <p>Products left: {quantity}</p>
           </div>
           <div className='price'>
                 <span className='rupees-icon'>
                      <BiRupee></BiRupee>
                 </span>
                 <span className='price-details'>{price}</span>
           </div>
        </Link>
    )
}
export default Product