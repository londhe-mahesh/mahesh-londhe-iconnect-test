import React, { useContext, useRef, useState } from 'react'
import { useParams } from 'react-router';
import GlobalState from './GlobalState'
import { Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
toast.configure()

function SignIn() {
    const [globalState] = useContext(GlobalState);
    let userName;

    const [user, updateUser] = useState({})
    const [isSignIn, setSignIn] = useState(false)
    const nameRef = useRef()
    const passwordRef = useRef()

    const currentUser = (e) => {
        if (e.target.id == "userName") {
            let name = nameRef.current.value;
            userName = name;
            updateUser(() => {
                return ({
                    ...user,
                    "name": name
                })
            })
        }
        else {
            let password = passwordRef.current.value;
            updateUser(() => {
                return ({
                    ...user,
                    "password": password
                })
            })
        }
    }
    const checkUser = (e) => {
        const name = user.name;
        const password = user.password;
        for (var i = 0; i < globalState.users.length; i++) {
            if (globalState.users[i].userName == name) {
                if (globalState.users[i].password == password) {
                    nameRef.current.value = "";
                    passwordRef.current.value = "";
                    toast.success(`Welcome ${name}`);
                    setSignIn(true)
                }
                else {
                    toast.error('password does not match.', { autoClose: false })
                    e.preventDefault()
                }
            }
            else {
                toast.error('Invalid user name or password.', { autoClose: false })
                e.preventDefault()
            }
        }
    }
    return (
        <div className='signin-wrapper'>

            {
                isSignIn ?
                    <div className='explore-section'>
                        <h2>Explore our products.</h2>
                        <Link to='/productList'>
                              <button className='explore-btn'>Explore</button>
                        </Link>
                    </div> :
                    <div className="form-wrapper">
                    <div className='site-header'>
                        <h1>Sign in to explore.</h1>
                    </div>
                    <div className="inner-wrapper">
                        <div className='user-action'>
                            <Link to='/SignIn'>
                                <div className='item current'>
                                    <h3>Sign In</h3>
                                </div>
                            </Link>
                            <Link to='/'>
                                <div className='item'>
                                    <h3>Sign Up</h3>
                                </div>
                            </Link>
                        </div>
                        <form>
                            <div className='form-field'>
                                <label className="form-label">Name</label>
                                <div className='input-group'>
                                    <input type="text" id="userName" ref={nameRef} onChange={
                                        (e) => {
                                            currentUser(e)
                                        }
                                    } />
                                </div>
                            </div>
    
                            <div className='form-field'>
                                <label className="form-label">Password</label>
                                <div className='input-group'>
                                    <input type="text" id="password" ref={passwordRef} onChange={
                                        (e) => {
                                            currentUser(e)
                                        }
                                    } />
                                </div>
                            </div>
                            <Link to='/productList'>
                                <button className='submit-btn' onClick={(e) => {
                                    e.preventDefault()
                                    checkUser(e);
                                }}>Sign In</button>
                            </Link>
                        </form>
                    </div>
                </div>
            }
        </div>
    )
}
export default SignIn