import React from 'react'

const GlobalState = React.createContext([{},()=>{}])

export default GlobalState