import React from 'react'
import SignUp from './SignUp';

function Home(){
   return(
       <div>
           <div className='site-header'>
              <h1>Welcome to Mahesh's Store</h1>
           </div>
           <SignUp></SignUp>
       </div>
   )
}
export default Home;