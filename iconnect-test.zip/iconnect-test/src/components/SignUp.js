import React, { useContext, useEffect, useRef, useState } from 'react'
import GlobalState from './GlobalState'
import { Link } from 'react-router-dom'
import {toast} from 'react-toastify'; 
import 'react-toastify/dist/ReactToastify.css'; 
toast.configure()

function SignUp() {
    const [globalState, updateGlobalState] = useContext(GlobalState)
    const [newUser, updateNewUser] = useState({})

    const nameRef = useRef();
    const passwordRef = useRef();
    const emailRef = useRef();

    useEffect(()=>{
        console.log("Global state is:", globalState)
    },[globalState])

    const updateUser = (e) => {
        if (e.target.id == "userName") {
            let name = nameRef.current.value
            updateNewUser((newUser) => ({
                ...newUser,
                "userName": name
            }))
        }
        else if(e.target.id == "password"){
            let password = passwordRef.current.value
            updateNewUser((newUser) => ({
                ...newUser,
                "password": password
            }))
        }
        else{
            let email = emailRef.current.value
            updateNewUser((newUser) => ({
                ...newUser,
                "email": email
            }))
        }
    }
    const handleSubmit = () => {
        if(newUser.userName && newUser.email && newUser.password){
            updateGlobalState(() => {
                return (
                    {
                        "users": [...globalState.users, newUser]
                    }
                )
            })
            toast.success('Sign up successful, please sign into your account.')
            nameRef.current.value="";
            emailRef.current.value="";
            passwordRef.current.value="";
            updateNewUser({});
        }
        else{
            toast.error('All fields are mandatory.', {autoClose:false})
        }
    }

    return (
            <div className="form-wrapper">
                <div className="inner-wrapper">
                   <div className='user-action'>
                     <Link to="/SignIn">
                        <div className='item'>
                            <h3>Sign In</h3>
                        </div>
                     </Link>
                     <div className='item current'>
                        <h3>Sign Up</h3>
                     </div>
                   </div>
                    <div>
                    <div className='form-field'>
                        <label className="form-label">Name</label>
                        <div className='input-group'>
                            <input type="text" id="userName" ref={nameRef} onChange={
                                (e) => {
                                    updateUser(e)
                                }
                            } />
                        </div>
                    </div>
                    <div className='form-field'>
                        <label className="form-label">email</label>
                        <div className='input-group'>
                            <input type="text" id="email" ref={emailRef} onChange={
                                (e) => {
                                    updateUser(e)
                                }
                            } />
                        </div>
                    </div>
                    <div className='form-field'>
                        <label className="form-label">Password</label>
                    <div className='input-group'>
                            <input type="text" id="password" ref={passwordRef} onChange={
                                    (e) => {
                                        updateUser(e)
                                    }
                                } />
                    </div>
                    </div>
                    <button className='submit-btn' onClick={(e) => {
                            // e.preventDefault()
                            handleSubmit();
                        }}>Sign Up
                    </button>
                </div>
                </div>
            </div>
    )
}
export default SignUp
