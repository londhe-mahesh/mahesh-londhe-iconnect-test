import React from 'react'
import { useParams } from 'react-router-dom'
import { BiRupee } from 'react-icons/bi'

function ProductDetails(props) {
    const { productId } = useParams()
    const { title, image, price, description, quantity } = props.location.state.product
    return (
        <div className='product-details-wrapper'>
            <div className='product-details product card'>
                <div className='detail-section'>
                    <div className='product-image'>
                        <img src={image} />
                    </div>
                    <div className='title'>
                        <p>{title}</p>
                    </div>
                </div>
                <div className='detail-section'>
                    <div className='description'>
                        <p>{description}</p>
                    </div>
                    <div className='quantity'>
                        <p>Products left:{quantity}</p>
                    </div>
                    <div className='price'>
                        <span className='rupees-icon'>
                            <BiRupee></BiRupee>
                        </span>
                        <span className='price-details'>{price}</span>
                    </div>
                    <button className='add-cart-btn'>Add To Cart</button>
                </div>
            </div>
        </div>
    )
}
export default ProductDetails