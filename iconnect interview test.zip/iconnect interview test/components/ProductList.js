import React, { useEffect, useState } from 'react'
import axios from 'axios'
import Product from './Product';
import data from '../data/productsData'

function ProductList() {
  const [productList, setProductList] = useState([]);
  const [isLoading, setLoader] = useState(false);

  const fetchProductData = () => {
    setProductList(data);
    console.log("Product list is:", productList)
  }
  useEffect(() => {
    fetchProductData();
  }, [])

  return (
    <div className='productlist-wrapper'>
          <div className='container'>
           <div className='list-title'>
                 <h2>Product's List</h2>
           </div>
            <div className='product-wrapper'>
              {
                isLoading ?
                  <p>Loading...</p> :
                  productList.map((singleProduct) => {
                    return (<Product product={singleProduct}></Product>)
                  })
              }
            </div>
          </div>
    </div>
  );
}
export default ProductList