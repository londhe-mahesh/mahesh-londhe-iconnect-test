const data = [
    {
        "id": 1,
        "title": "fashnable womens bag",
        "image": "https://fakestoreapi.com/img/81fPKd-2AYL._AC_SL1500_.jpg",
        "quantity": 10,
        "price": 1200,
        "description": "Perfect fashnable product to suit your personality and make you look comfortable and preity."
    },
    {
        "id": 2,
        "title": "tshirt",
        "image": "https://fakestoreapi.com/img/71-3HjGNDUL._AC_SY879._SX._UX._SY._UY_.jpg",
        "quantity": 8,
        "price": 900,
        "description": "Perfect fashnable product to suit your personality and make you look comfortable and preity."
    },
    {
        "id": 3,
        "title": "tshirt",
        "image": "https://fakestoreapi.com/img/71HblAHs5xL._AC_UY879_-2.jpg",
        "quantity": 10,
        "price": 900,
        "description": "Perfect fashnable product to suit your personality and make you look comfortable and preity."
    },
    {
        "id": 4,
        "title": "tshirt",
        "image": "https://fakestoreapi.com/img/71YXzeOuslL._AC_UY879_.jpg",
        "quantity": 20,
        "price": 600,
        "description": "Perfect fashnable product to suit your personality and make you look comfortable and preity."
    },
    {
        "id": 5,
        "title": "tshirt",
        "image": "https://fakestoreapi.com/img/71pWzhdJNwL._AC_UL640_QL65_ML3_.jpg",
        "quantity": 7,
        "price": 600,
        "description": "Perfect fashnable product to suit your personality and make you look comfortable and preity."
    },
    {
        "id": 6,
        "title": "Womens silver Bracelet",
        "image": "https://fakestoreapi.com/img/61sbMiUnoGL._AC_UL640_QL65_ML3_.jpg",
        "price": 30,
        "description": "Perfect fashnable product to suit your personality and make you look comfortable and preity."
    },
    {
        "id": 7,
        "title": "Bangles",
        "image": "https://fakestoreapi.com/img/71YAIFU48IL._AC_UL640_QL65_ML3_.jpg",
        "quantity": 20,
        "price": 1300,
        "description": "Perfect fashionable product to suit your personality and make you look comfortable and preity."
    },
    {
        "id": 8,
        "title": "Rose Gold Plated Double Flared Tunnel Plug Earrings.",
        "image": "https://fakestoreapi.com/img/51UDEzMJVpL._AC_UL640_QL65_ML3_.jpg",
        "quantity": 18,
        "price": 900,
        "description": "Pierced Owl Rose Gold Plated Stainless Steel Double"
    },
    {
        "id": 10,
        "title": "Rose Gold Plated Double Flared Tunnel Plug Earrings.",
        "image": "https://fakestoreapi.com/img/61U7T1koQqL._AC_SX679_.jpg",
        "quantity": 23,
        "price": 2000,
        "description": "Pierced Owl Rose Gold Plated Stainless Steel Double"
    },
    {
        "id": 11,
        "title": "Silicon power bank.",
        "image": "https://fakestoreapi.com/img/61mtL65D4cL._AC_SX679_.jpg",
        "quantity": 18,
        "price": 1200,
        "description": "Portable External Hard Drive, with 5 years manufactureing warranty"
    },
    {
        "id": 12,
        "title": "LCD tv.",
        "image": "https://fakestoreapi.com/img/61mtL65D4cL._AC_SX679_.jpg",
        "quantity": 16,
        "price": 1200,
        "description": "21.5 inches Full HD (1920 x 1080) widescreen IPS display And Radeon free Sync technology. Horizontal viewing angle-178 degree."
    },
    {
        "id": 13,
        "title": "Jacket",
        image: "https://fakestoreapi.com/img/81XH0e8fefL._AC_UY879_.jpg",
        "quantity": 16,
        "price": 2000,
        "description": "Womens jacket for all season, with cpmfortable fittings"
    },
    {
        "id": 14,
        "title": "tshirt",
        image: "https://fakestoreapi.com/img/71HblAHs5xL._AC_UY879_-2.jpg",
        "quantity": 13,
        "price": 1000,
        "description": "Lightweight perfet for trip or casual wear-Long sleeve with hooded, adjustable drawstring waist design. Button and zipper front closure raincoat"
    },
    {
        "id": 15,
        "title": "tshirt",
        image: "https://fakestoreapi.com/img/71z3kpMAYsL._AC_UY879_.jpg",
        "quantity": 12,
        "price": 1200,
        "description": "Made in USA or Imported, Do Not Bleach, Lightweight fabric with great stretch for comfort, Ribbed on sleeves and neckline / Double stitching on bottom hem"
    },
    {
        "id": 16,
        "title": "tshirt",
        image: "https://fakestoreapi.com/img/61pHAEJ4NML._AC_UX679_.jpg",
        "quantity": 11,
        "price": 2900,
        "description": "Perfect fashnable product to suit your personality and make you look comfortable and preity."
    },
    {
        "id": 16,
        "title": "Silicon power bank.",
        "image": "https://fakestoreapi.com/img/61mtL65D4cL._AC_SX679_.jpg",
        "quantity": 22,
        "price": 1200,
        "description": "Portable External Hard Drive, with 5 years manufactureing warranty"
    }
    
]
export default data